PROYECTO CVSTUDIO - MARCOS A. POUSA
Sitio: index.html
Logo: assets/logo-mp.svg
Retrato transparente: assets/marcos-pousa.webp

Para migrar: subir el contenido del ZIP al directorio del dominio. Debe configurarse HTTPS y acceso de administrador con backend seguro; el panel de demo utiliza localStorage, no sincroniza entre dispositivos. Los datos de demostración no son un sistema de gestión de clientes.

Verificar todos los enlaces y las versiones móvil y escritorio antes de publicar.